<?php
$action = $data['action'] ?? ( $_POST['action'] ?? '' );

try {
	if ( $action === 'save_settings' ) {
		if ( isset( $data['org_name'] ) ) {
			$db->save_kitchen_settings( sanitize_text_field( $data['org_name'] ) );
		}
		if ( isset( $data['tm_approver_position'] ) || isset( $data['tm_approver_name'] ) ) {
			$db->save_tm_approver(
				sanitize_text_field( $data['tm_approver_position'] ?? '' ),
				sanitize_text_field( $data['tm_approver_name'] ?? '' )
			);
		}
		if ( isset( $data['academic_year_start'] ) || isset( $data['academic_year_end'] ) || isset( $data['reset_cycle_after_vacation'] ) ) {
			$db->save_academic_year_settings(
				sanitize_text_field( $data['academic_year_start'] ?? '09-01' ),
				sanitize_text_field( $data['academic_year_end'] ?? '05-26' ),
				(int) ( $data['reset_cycle_after_vacation'] ?? 0 )
			);
		}

		if ( isset( $data['meal_food_dir'] ) ) {
			$path = sanitize_text_field( $data['meal_food_dir'] );
			if ( $path === '' || $path === ABSPATH . 'food' || $path === ABSPATH . 'food/' ) {
				delete_option( 'meal_food_dir' );
			} else {
				update_option( 'meal_food_dir', untrailingslashit( $path ) );
			}
		}

		if ( isset( $data['meal_ai_prompt'] ) ) {
			$prompt = trim( $data['meal_ai_prompt'] );
			if ( $prompt === '' || $prompt === \Meal_Menu\Importer_Photo::get_default_prompt() ) {
				delete_option( 'meal_ai_prompt' );
			} else {
				update_option( 'meal_ai_prompt', $prompt );
			}
		}

		$smtp_keys = array( 'meal_admin_email', 'meal_mail_from', 'meal_mail_from_name', 'meal_smtp_host', 'meal_smtp_user', 'meal_smtp_pass', 'meal_smtp_port', 'meal_smtp_secure' );
		foreach ( $smtp_keys as $key ) {
			if ( isset( $data[ $key ] ) ) {
				update_option( $key, sanitize_text_field( $data[ $key ] ) );
			}
		}

		if ( isset( $data['departments'] ) && is_array( $data['departments'] ) ) {
			foreach ( $data['departments'] as $dept_data ) {
				$id = (int) ( $dept_data['id'] ?? 0 );
				if ( ! $id ) {
					continue;
				}
				$db->save_department( $id, $dept_data );
			}
		}

		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} elseif ( $action === 'add_department' ) {
		$code        = sanitize_key( $data['code'] ?? '' );
		$label       = sanitize_text_field( $data['label'] ?? '' );
		$file_suffix = sanitize_text_field( $data['file_suffix'] ?? '' );
		if ( empty( $code ) || empty( $label ) ) {
			wp_send_json( array( 'ok' => false, 'error' => __( 'Заполните код и название', 'meal-menu' ) ) );
		}
		$id = $db->add_department( $code, $label, $file_suffix );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true, 'id' => $id ) );

	} elseif ( $action === 'delete_department' ) {
		$id = isset( $data['id'] ) ? (int) $data['id'] : 0;
		$db->delete_department( $id );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} elseif ( $action === 'resort_departments' ) {
		$order = is_array( $data['order'] ?? null ) ? $data['order'] : array();
		$db->resort_departments( $order );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} elseif ( $action === 'add_vacation' ) {
		$academic_year = sanitize_text_field( $data['academic_year'] ?? '' );
		$label         = sanitize_text_field( $data['label'] ?? '' );
		$date_from     = sanitize_text_field( $data['date_from'] ?? '' );
		$date_to       = sanitize_text_field( $data['date_to'] ?? '' );
		$id = $db->add_vacation( $academic_year, $label, $date_from, $date_to );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true, 'id' => $id ) );

	} elseif ( $action === 'update_vacation' ) {
		$id        = isset( $data['id'] ) ? (int) $data['id'] : 0;
		$label     = sanitize_text_field( $data['label'] ?? '' );
		$date_from = sanitize_text_field( $data['date_from'] ?? '' );
		$date_to   = sanitize_text_field( $data['date_to'] ?? '' );
		$db->update_vacation( $id, $label, $date_from, $date_to );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} elseif ( $action === 'delete_vacation' ) {
		$id = isset( $data['id'] ) ? (int) $data['id'] : 0;
		$db->delete_vacation( $id );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} elseif ( $action === 'get_vacations' ) {
		$academic_year = sanitize_text_field( $data['academic_year'] ?? $db->get_academic_year_for_date( current_time( 'Y-m-d' ) ) );
		$vacations     = $db->get_vacations( $academic_year );
		wp_send_json( array( 'ok' => true, 'vacations' => $vacations ) );

	} elseif ( $action === 'get_holidays' ) {
		$holidays = $db->get_holidays();
		wp_send_json( array( 'ok' => true, 'holidays' => $holidays ) );

	} elseif ( $action === 'add_holiday' ) {
		$label       = sanitize_text_field( $data['label'] ?? '' );
		$month_day   = sanitize_text_field( $data['month_day'] ?? '' );
		$month_day_to = ! empty( $data['month_day_to'] ) ? sanitize_text_field( $data['month_day_to'] ) : null;
		$id = $db->add_holiday( $label, $month_day, $month_day_to );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true, 'id' => $id ) );

	} elseif ( $action === 'delete_holiday' ) {
		$id = isset( $data['id'] ) ? (int) $data['id'] : 0;
		$db->delete_holiday( $id );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} elseif ( $action === 'fill_default_holidays' ) {
		global $wpdb;
		$t = $db->get_table_name( 'holidays' );
		// Remove old separate new year entries, replace with range
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM $t WHERE month_day IN ('01-01','01-02','01-03','01-04','01-05','01-06','01-07','01-08')"
		) );
		$defaults = array(
			array( 'Новогодние каникулы',  '01-01', '01-08' ),
			array( 'День защитника Отечества',  '02-23' ),
			array( 'Международный женский день', '03-08' ),
			array( 'Праздник Весны и Труда',    '05-01' ),
			array( 'День Победы',               '05-09' ),
			array( 'День России',               '06-12' ),
			array( 'День народного единства',   '11-04' ),
		);
		$existing = $db->get_holidays();
		$existing_dates = array();
		foreach ( $existing as $ex ) {
			$existing_dates[ $ex['month_day'] ] = true;
		}
		foreach ( $defaults as $h ) {
			if ( ! isset( $existing_dates[ $h[1] ] ) ) {
				$db->add_holiday( $h[0], $h[1], $h[2] ?? null );
			}
		}
		$holidays = $db->get_holidays();
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true, 'holidays' => $holidays, 'message' => __( 'Государственные праздники добавлены', 'meal-menu' ) ) );

	} elseif ( $action === 'fill_default_vacations' ) {
		$academic_year = sanitize_text_field( $data['academic_year'] ?? '' );
		if ( empty( $academic_year ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'Academic year required' ) );
		}
		$parts = explode( '-', $academic_year );
		$y     = (int) $parts[0];
		$ny    = $y + 1;

		$ay_settings = $db->get_academic_year_settings();
		$summer_start = date_create( "$ny-{$ay_settings['academic_year_end']}" )->modify( '+1 day' )->format( 'Y-m-d' );
		$summer_end   = date_create( "$ny-{$ay_settings['academic_year_start']}" )->modify( '-1 day' )->format( 'Y-m-d' );

		$defaults = array(
			array( 'Осенние каникулы',
				date_create( "last monday of October $y" )->format( 'Y-m-d' ),
				date_create( "last monday of October $y +6 days" )->format( 'Y-m-d' ),
			),
			array( 'Зимние каникулы',
				date_create( "last monday of December $y" )->format( 'Y-m-d' ),
				date_create( "second monday of January $ny -1 day" )->format( 'Y-m-d' ),
			),
			array( 'Весенние каникулы',
				date_create( "last monday of March $ny" )->format( 'Y-m-d' ),
				date_create( "last monday of March $ny +6 days" )->format( 'Y-m-d' ),
			),
			array( 'Летние каникулы', $summer_start, $summer_end ),
		);

		foreach ( $defaults as $def ) {
			$db->add_vacation( $academic_year, $def[0], $def[1], $def[2] );
		}

		$vacations = $db->get_vacations( $academic_year );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true, 'vacations' => $vacations, 'message' => __( 'Типовые каникулы добавлены', 'meal-menu' ) ) );

	} elseif ( $action === 'import_data' ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json( array( 'ok' => false, 'error' => __( 'Недостаточно прав', 'meal-menu' ) ) );
		}
		$payload = $data['payload'] ?? null;
		if ( ! $payload || ! is_array( $payload ) ) {
			wp_send_json( array( 'ok' => false, 'error' => __( 'Неверный формат данных', 'meal-menu' ) ) );
		}

		global $wpdb;
		$p     = $wpdb->prefix . 'meal_';
		$parents = array( 'templates', 'users', 'departments', 'kitchen_settings', 'holidays', 'vacations', 'oc_monitoring' );
		$children = array( 'items', 'calendar', 'email_tokens' );
		$all = array_merge( $children, $parents );

		try {
			foreach ( $all as $table ) {
				$wpdb->query( "DELETE FROM {$p}{$table}" );
			}

			foreach ( $parents as $table ) {
				if ( empty( $payload[ $table ] ) ) {
					continue;
				}
				foreach ( $payload[ $table ] as $row ) {
					$wpdb->insert( "{$p}{$table}", $row );
				}
			}

			foreach ( $children as $table ) {
				if ( empty( $payload[ $table ] ) ) {
					continue;
				}
				foreach ( $payload[ $table ] as $row ) {
					$wpdb->insert( "{$p}{$table}", $row );
				}
			}

			if ( ! empty( $payload['_options'] ) ) {
				foreach ( $payload['_options'] as $opt => $val ) {
					update_option( $opt, $val );
				}
			}
		} catch ( \Exception $e ) {
			wp_send_json( array( 'ok' => false, 'error' => $e->getMessage() ) );
		}

		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} elseif ( $action === 'seed_default_departments' ) {
		if ( ! current_user_can( 'manage_meal_menu' ) ) {
			wp_send_json( array( 'ok' => false, 'error' => __( 'Недостаточно прав', 'meal-menu' ) ) );
		}
		$inst_type = $data['institution_type'] ?? $db->get_institution_type();
		$db->save_kitchen_settings_bulk( array( 'institution_type' => $inst_type ) );
		$db->seed_default_departments( $inst_type );
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true, 'message' => __( 'Типовые отделения установлены', 'meal-menu' ) ) );

	} elseif ( $action === 'reset_ai_prompt' ) {
		delete_option( 'meal_ai_prompt' );
		wp_send_json( array(
			'ok'     => true,
			'prompt' => \Meal_Menu\Importer_Photo::get_default_prompt(),
		) );

	} elseif ( $action === 'reset_data' ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( -1 );
		}
		\Meal_Menu\Activator::uninstall();
		\Meal_Menu\Activator::activate();
		\Meal_Menu\Shortcodes::invalidate_calendar_cache();
		wp_send_json( array( 'ok' => true ) );

	} else {
		wp_send_json( array( 'ok' => false, 'error' => __( 'Неизвестное действие', 'meal-menu' ) ) );
	}
} catch ( \Exception $e ) {
	wp_send_json( array( 'ok' => false, 'error' => $e->getMessage() ) );
}
